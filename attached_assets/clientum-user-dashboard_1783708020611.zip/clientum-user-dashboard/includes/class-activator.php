<?php
/**
 * Activation routine.
 *
 * @package Clientum\UserDashboard
 */

namespace Clientum\UserDashboard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Activator {

	/**
	 * Runs once on plugin activation. The plugin has no custom tables — it
	 * only reads/writes core WordPress users and usermeta — so activation
	 * just makes sure rewrite rules pick up nothing new and clears any
	 * stale object cache for the dashboard page lookup.
	 */
	public static function activate(): void {
		flush_rewrite_rules();
	}
}
