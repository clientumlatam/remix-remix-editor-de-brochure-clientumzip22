<?php
/**
 * Frontend account dashboard — shortcode, assets, and markup.
 *
 * @package Clientum\UserDashboard
 */

namespace Clientum\UserDashboard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dashboard {

	private bool $shortcode_rendered = false;

	public function init(): void {
		add_shortcode( 'clientum_user_dashboard', array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_assets' ) );
	}

	/**
	 * Enqueues assets only on pages/posts whose content contains the
	 * shortcode, so the dashboard's CSS/JS never leaks onto the rest of
	 * the site.
	 */
	public function maybe_enqueue_assets(): void {
		if ( ! is_singular() ) {
			return;
		}

		$post = get_post();
		if ( ! $post || ! has_shortcode( (string) $post->post_content, 'clientum_user_dashboard' ) ) {
			return;
		}

		wp_enqueue_style(
			'clientum-user-dashboard',
			CUD_PLUGIN_URL . 'assets/css/dashboard.css',
			array(),
			CUD_VERSION
		);

		wp_enqueue_script(
			'clientum-user-dashboard',
			CUD_PLUGIN_URL . 'assets/js/dashboard.js',
			array(),
			CUD_VERSION,
			true
		);

		wp_localize_script( 'clientum-user-dashboard', 'ClientumDashboard', array(
			'restUrl' => esc_url_raw( rest_url( 'clientum/v1' ) ),
			'nonce'   => wp_create_nonce( 'wp_rest' ),
			'strings' => array(
				'saved'        => __( 'Cambios guardados.', 'clientum-user-dashboard' ),
				'error'        => __( 'Ocurrió un error. Intentá de nuevo.', 'clientum-user-dashboard' ),
				'wrongPassword' => __( 'La contraseña actual no es correcta.', 'clientum-user-dashboard' ),
				'passwordMismatch' => __( 'Las contraseñas nuevas no coinciden.', 'clientum-user-dashboard' ),
				'passwordUpdated' => __( 'Contraseña actualizada. Volvé a iniciar sesión la próxima vez con la nueva.', 'clientum-user-dashboard' ),
			),
		) );
	}

	/**
	 * Shortcode handler: [clientum_user_dashboard]
	 */
	public function render(): string {
		if ( ! is_user_logged_in() ) {
			return $this->render_login_prompt();
		}

		$user = wp_get_current_user();

		ob_start();
		?>
		<div class="cud-wrap" id="cud-app" data-user-id="<?php echo esc_attr( $user->ID ); ?>">
			<aside class="cud-side">
				<div class="cud-side__profile">
					<?php echo get_avatar( $user->ID, 64, '', '', array( 'class' => 'cud-avatar' ) ); ?>
					<div>
						<p class="cud-side__name"><?php echo esc_html( $user->display_name ); ?></p>
						<p class="cud-side__email"><?php echo esc_html( $user->user_email ); ?></p>
					</div>
				</div>
				<nav class="cud-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Secciones de tu cuenta', 'clientum-user-dashboard' ); ?>">
					<button class="cud-tab is-active" data-tab="perfil" role="tab" aria-selected="true"><?php esc_html_e( 'Mi perfil', 'clientum-user-dashboard' ); ?></button>
					<button class="cud-tab" data-tab="suscripcion" role="tab" aria-selected="false"><?php esc_html_e( 'Mi suscripción', 'clientum-user-dashboard' ); ?></button>
					<button class="cud-tab" data-tab="seguridad" role="tab" aria-selected="false"><?php esc_html_e( 'Seguridad', 'clientum-user-dashboard' ); ?></button>
				</nav>
				<a class="cud-logout" href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>"><?php esc_html_e( 'Cerrar sesión', 'clientum-user-dashboard' ); ?></a>
			</aside>

			<main class="cud-content">
				<div class="cud-alert" id="cud-alert" hidden></div>

				<section class="cud-panel is-active" data-panel="perfil">
					<h2><?php esc_html_e( 'Mi perfil', 'clientum-user-dashboard' ); ?></h2>
					<p class="cud-hint"><?php esc_html_e( 'Actualizá tus datos de contacto.', 'clientum-user-dashboard' ); ?></p>
					<form id="cud-profile-form" class="cud-form">
						<div class="cud-field-row">
							<label class="cud-field">
								<span><?php esc_html_e( 'Nombre', 'clientum-user-dashboard' ); ?></span>
								<input type="text" name="first_name" value="<?php echo esc_attr( get_user_meta( $user->ID, 'first_name', true ) ); ?>" maxlength="120">
							</label>
							<label class="cud-field">
								<span><?php esc_html_e( 'Apellido', 'clientum-user-dashboard' ); ?></span>
								<input type="text" name="last_name" value="<?php echo esc_attr( get_user_meta( $user->ID, 'last_name', true ) ); ?>" maxlength="120">
							</label>
						</div>
						<label class="cud-field">
							<span><?php esc_html_e( 'Nombre a mostrar', 'clientum-user-dashboard' ); ?></span>
							<input type="text" name="display_name" value="<?php echo esc_attr( $user->display_name ); ?>" maxlength="120">
						</label>
						<label class="cud-field">
							<span><?php esc_html_e( 'Teléfono', 'clientum-user-dashboard' ); ?></span>
							<input type="tel" name="phone" value="<?php echo esc_attr( get_user_meta( $user->ID, 'cud_phone', true ) ); ?>" maxlength="40">
						</label>
						<label class="cud-field">
							<span><?php esc_html_e( 'Email', 'clientum-user-dashboard' ); ?></span>
							<input type="email" value="<?php echo esc_attr( $user->user_email ); ?>" disabled>
							<small><?php esc_html_e( 'Para cambiar tu email, contactá a soporte.', 'clientum-user-dashboard' ); ?></small>
						</label>
						<button type="submit" class="cud-btn"><?php esc_html_e( 'Guardar cambios', 'clientum-user-dashboard' ); ?></button>
					</form>
				</section>

				<section class="cud-panel" data-panel="suscripcion">
					<h2><?php esc_html_e( 'Mi suscripción', 'clientum-user-dashboard' ); ?></h2>
					<?php echo $this->render_subscription_panel( $user->user_email ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped in helper. ?>
				</section>

				<section class="cud-panel" data-panel="seguridad">
					<h2><?php esc_html_e( 'Seguridad', 'clientum-user-dashboard' ); ?></h2>
					<p class="cud-hint"><?php esc_html_e( 'Cambiá tu contraseña de acceso.', 'clientum-user-dashboard' ); ?></p>
					<form id="cud-password-form" class="cud-form">
						<label class="cud-field">
							<span><?php esc_html_e( 'Contraseña actual', 'clientum-user-dashboard' ); ?></span>
							<input type="password" name="current_password" autocomplete="current-password" required>
						</label>
						<div class="cud-field-row">
							<label class="cud-field">
								<span><?php esc_html_e( 'Nueva contraseña', 'clientum-user-dashboard' ); ?></span>
								<input type="password" name="new_password" autocomplete="new-password" minlength="8" required>
							</label>
							<label class="cud-field">
								<span><?php esc_html_e( 'Confirmar nueva contraseña', 'clientum-user-dashboard' ); ?></span>
								<input type="password" name="confirm_password" autocomplete="new-password" minlength="8" required>
							</label>
						</div>
						<button type="submit" class="cud-btn"><?php esc_html_e( 'Actualizar contraseña', 'clientum-user-dashboard' ); ?></button>
					</form>
				</section>
			</main>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private function render_login_prompt(): string {
		ob_start();
		?>
		<div class="cud-wrap cud-wrap--guest">
			<div class="cud-login-card">
				<h2><?php esc_html_e( 'Ingresá a tu cuenta', 'clientum-user-dashboard' ); ?></h2>
				<p class="cud-hint"><?php esc_html_e( 'Iniciá sesión para ver tu panel de usuario.', 'clientum-user-dashboard' ); ?></p>
				<?php
				wp_login_form( array(
					'redirect' => get_permalink(),
					'label_log_in' => __( 'Ingresar', 'clientum-user-dashboard' ),
				) );
				?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * If AI Marketing Expert is active, look up this user by email in its
	 * subscribers table and show their marketing status read-only. Falls
	 * back to a friendly empty state when the plugin isn't installed or the
	 * email has no matching subscriber yet.
	 */
	private function render_subscription_panel( string $email ): string {
		global $wpdb;
		$table = $wpdb->prefix . 'aime_subscribers';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off existence check, not a repeated query.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );

		if ( ! $table_exists ) {
			return '<p class="cud-empty">' . esc_html__( 'La gestión de suscripciones no está disponible en este sitio.', 'clientum-user-dashboard' ) . '</p>';
		}

		$subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT status, created_at FROM {$table} WHERE email = %s LIMIT 1", $email ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! $subscriber ) {
			return '<p class="cud-empty">' . esc_html__( 'Todavía no estás en ninguna lista de suscripción.', 'clientum-user-dashboard' ) . '</p>';
		}

		$status_labels = array(
			'subscribed'   => __( 'Suscripto', 'clientum-user-dashboard' ),
			'pending'      => __( 'Pendiente de confirmación', 'clientum-user-dashboard' ),
			'unsubscribed' => __( 'Dado de baja', 'clientum-user-dashboard' ),
			'bounced'      => __( 'Email rechazado', 'clientum-user-dashboard' ),
			'complained'   => __( 'Marcado como spam', 'clientum-user-dashboard' ),
		);
		$status_label = $status_labels[ $subscriber->status ] ?? $subscriber->status;

		ob_start();
		?>
		<div class="cud-sub-status cud-sub-status--<?php echo esc_attr( $subscriber->status ); ?>">
			<span class="cud-sub-dot"></span>
			<span><?php echo esc_html( $status_label ); ?></span>
		</div>
		<p class="cud-hint">
			<?php
			printf(
				/* translators: %s: subscription date */
				esc_html__( 'Suscripto desde el %s.', 'clientum-user-dashboard' ),
				esc_html( mysql2date( get_option( 'date_format' ), (string) $subscriber->created_at ) )
			);
			?>
		</p>
		<?php
		return (string) ob_get_clean();
	}
}
