<?php
/**
 * REST endpoints backing the account dashboard's AJAX forms.
 *
 * Every route only ever reads/writes the *currently authenticated* user —
 * there is no user-ID parameter accepted from the client — so there is no
 * way for one logged-in user to touch another user's data.
 *
 * @package Clientum\UserDashboard
 */

namespace Clientum\UserDashboard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RestController {

	private const NAMESPACE = 'clientum/v1';

	public function init(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route( self::NAMESPACE, '/profile', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'update_profile' ),
			'permission_callback' => array( $this, 'check_logged_in' ),
			'args'                => array(
				'first_name'   => array( 'type' => 'string' ),
				'last_name'    => array( 'type' => 'string' ),
				'display_name' => array( 'type' => 'string' ),
				'phone'        => array( 'type' => 'string' ),
			),
		) );

		register_rest_route( self::NAMESPACE, '/password', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'update_password' ),
			'permission_callback' => array( $this, 'check_logged_in' ),
			'args'                => array(
				'current_password' => array( 'type' => 'string', 'required' => true ),
				'new_password'     => array( 'type' => 'string', 'required' => true ),
			),
		) );
	}

	public function check_logged_in(): bool {
		return is_user_logged_in();
	}

	public function update_profile( \WP_REST_Request $request ): \WP_REST_Response {
		$user_id = get_current_user_id();

		$first_name   = sanitize_text_field( (string) $request->get_param( 'first_name' ) );
		$last_name    = sanitize_text_field( (string) $request->get_param( 'last_name' ) );
		$display_name = sanitize_text_field( (string) $request->get_param( 'display_name' ) );
		$phone        = sanitize_text_field( (string) $request->get_param( 'phone' ) );

		if ( mb_strlen( $first_name ) > 120 || mb_strlen( $last_name ) > 120 || mb_strlen( $display_name ) > 120 || mb_strlen( $phone ) > 40 ) {
			return new \WP_REST_Response( array( 'message' => __( 'Uno de los campos supera la longitud permitida.', 'clientum-user-dashboard' ) ), 400 );
		}

		$update = array( 'ID' => $user_id );
		if ( '' !== $display_name ) {
			$update['display_name'] = $display_name;
		}

		$result = wp_update_user( $update );
		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( array( 'message' => $result->get_error_message() ), 400 );
		}

		update_user_meta( $user_id, 'first_name', $first_name );
		update_user_meta( $user_id, 'last_name', $last_name );
		update_user_meta( $user_id, 'cud_phone', $phone );

		return new \WP_REST_Response( array( 'message' => __( 'Perfil actualizado.', 'clientum-user-dashboard' ) ) );
	}

	public function update_password( \WP_REST_Request $request ): \WP_REST_Response {
		$user = wp_get_current_user();

		$current_password = (string) $request->get_param( 'current_password' );
		$new_password     = (string) $request->get_param( 'new_password' );

		if ( ! wp_check_password( $current_password, $user->user_pass, $user->ID ) ) {
			return new \WP_REST_Response( array( 'message' => __( 'La contraseña actual no es correcta.', 'clientum-user-dashboard' ) ), 403 );
		}

		if ( mb_strlen( $new_password ) < 8 ) {
			return new \WP_REST_Response( array( 'message' => __( 'La nueva contraseña debe tener al menos 8 caracteres.', 'clientum-user-dashboard' ) ), 400 );
		}

		wp_set_password( $new_password, $user->ID );

		// wp_set_password() destroys the current session's auth cookie, so
		// re-issue one for this same request rather than forcing an
		// immediate re-login the user didn't ask for.
		wp_set_auth_cookie( $user->ID );

		return new \WP_REST_Response( array( 'message' => __( 'Contraseña actualizada.', 'clientum-user-dashboard' ) ) );
	}
}
