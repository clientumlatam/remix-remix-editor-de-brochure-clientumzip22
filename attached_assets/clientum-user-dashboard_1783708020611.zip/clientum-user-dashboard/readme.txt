=== Clientum – Panel de Usuario ===
Contributors: clientum
Tags: dashboard, user account, frontend, membership
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

Panel de cuenta en el frontend para que cada usuario logueado gestione su perfil y su contraseña, sin pasar por wp-admin.

== Description ==

Insertá el shortcode `[clientum_user_dashboard]` en cualquier página (por ejemplo, "Mi Cuenta") para mostrar un panel con tres secciones:

* **Mi perfil** — nombre, apellido, nombre a mostrar y teléfono.
* **Mi suscripción** — si el plugin "AI Marketing Expert" está activo, muestra el estado de suscripción del usuario (suscripto, pendiente, dado de baja, etc.) buscando su email en la tabla de suscriptores. Si no está instalado, muestra un mensaje vacío en su lugar.
* **Seguridad** — cambio de contraseña, con verificación de la contraseña actual.

Los visitantes no logueados ven un formulario de inicio de sesión en el mismo lugar.

Todas las acciones (guardar perfil, cambiar contraseña) se hacen vía la REST API de WordPress, autenticadas con nonce, y solo pueden modificar los datos del usuario que está logueado — nunca los de otro usuario.

== Installation ==

1. Subí la carpeta `clientum-user-dashboard` a `/wp-content/plugins/`.
2. Activá el plugin desde el panel de administración.
3. Creá o editá una página y agregá el shortcode `[clientum_user_dashboard]`.

== Changelog ==

= 1.0.0 =
* Versión inicial: perfil, seguridad y estado de suscripción (si AI Marketing Expert está activo).
