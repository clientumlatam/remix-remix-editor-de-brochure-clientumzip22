( function () {
	'use strict';

	var app = document.getElementById( 'cud-app' );
	if ( ! app || typeof ClientumDashboard === 'undefined' ) {
		return;
	}

	var strings = ClientumDashboard.strings || {};

	/* ── Tabs ── */
	var tabs = app.querySelectorAll( '.cud-tab' );
	var panels = app.querySelectorAll( '.cud-panel' );

	tabs.forEach( function ( tab ) {
		tab.addEventListener( 'click', function () {
			var target = tab.getAttribute( 'data-tab' );

			tabs.forEach( function ( t ) {
				t.classList.toggle( 'is-active', t === tab );
				t.setAttribute( 'aria-selected', t === tab ? 'true' : 'false' );
			} );

			panels.forEach( function ( panel ) {
				panel.classList.toggle( 'is-active', panel.getAttribute( 'data-panel' ) === target );
			} );
		} );
	} );

	/* ── Alert helper ── */
	var alertBox = document.getElementById( 'cud-alert' );

	function showAlert( message, type ) {
		if ( ! alertBox ) {
			return;
		}
		alertBox.textContent = message;
		alertBox.className = 'cud-alert cud-alert--' + ( type || 'success' );
		alertBox.hidden = false;
		alertBox.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
	}

	function request( path, body ) {
		return fetch( ClientumDashboard.restUrl + path, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': ClientumDashboard.nonce,
			},
			body: JSON.stringify( body ),
		} ).then( function ( response ) {
			return response.json().then( function ( data ) {
				return { ok: response.ok, data: data };
			} );
		} );
	}

	/* ── Profile form ── */
	var profileForm = document.getElementById( 'cud-profile-form' );
	if ( profileForm ) {
		profileForm.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var submitBtn = profileForm.querySelector( 'button[type="submit"]' );
			submitBtn.disabled = true;

			var payload = {
				first_name: profileForm.first_name.value,
				last_name: profileForm.last_name.value,
				display_name: profileForm.display_name.value,
				phone: profileForm.phone.value,
			};

			request( '/profile', payload )
				.then( function ( res ) {
					if ( res.ok ) {
						showAlert( res.data.message || strings.saved, 'success' );
						var nameLabel = app.querySelector( '.cud-side__name' );
						if ( nameLabel && payload.display_name ) {
							nameLabel.textContent = payload.display_name;
						}
					} else {
						showAlert( res.data.message || strings.error, 'error' );
					}
				} )
				.catch( function () {
					showAlert( strings.error, 'error' );
				} )
				.finally( function () {
					submitBtn.disabled = false;
				} );
		} );
	}

	/* ── Password form ── */
	var passwordForm = document.getElementById( 'cud-password-form' );
	if ( passwordForm ) {
		passwordForm.addEventListener( 'submit', function ( e ) {
			e.preventDefault();

			if ( passwordForm.new_password.value !== passwordForm.confirm_password.value ) {
				showAlert( strings.passwordMismatch, 'error' );
				return;
			}

			var submitBtn = passwordForm.querySelector( 'button[type="submit"]' );
			submitBtn.disabled = true;

			request( '/password', {
				current_password: passwordForm.current_password.value,
				new_password: passwordForm.new_password.value,
			} )
				.then( function ( res ) {
					if ( res.ok ) {
						showAlert( res.data.message || strings.passwordUpdated, 'success' );
						passwordForm.reset();
					} else {
						showAlert( res.data.message || strings.error, 'error' );
					}
				} )
				.catch( function () {
					showAlert( strings.error, 'error' );
				} )
				.finally( function () {
					submitBtn.disabled = false;
				} );
		} );
	}
} )();
