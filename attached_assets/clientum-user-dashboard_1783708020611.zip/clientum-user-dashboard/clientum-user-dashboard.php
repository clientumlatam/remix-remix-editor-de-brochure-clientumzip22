<?php
/**
 * Plugin Name:       Clientum – Panel de Usuario
 * Plugin URI:        https://clientum.com
 * Description:       Panel de cuenta en el frontend para que cada usuario gestione su perfil, seguridad y (si AI Marketing Expert está activo) su estado de suscripción. Insertalo con el shortcode [clientum_user_dashboard].
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      8.0
 * Author:            Clientum
 * Text Domain:       clientum-user-dashboard
 *
 * @package Clientum\UserDashboard
 */

namespace Clientum\UserDashboard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CUD_VERSION', '1.0.0' );
define( 'CUD_PLUGIN_FILE', __FILE__ );
define( 'CUD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CUD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once CUD_PLUGIN_DIR . 'includes/class-dashboard.php';
require_once CUD_PLUGIN_DIR . 'includes/class-rest-controller.php';
require_once CUD_PLUGIN_DIR . 'includes/class-activator.php';

register_activation_hook( __FILE__, array( Activator::class, 'activate' ) );

/**
 * Boot the plugin once WordPress finishes loading plugins, so it can safely
 * detect whether AI Marketing Expert is active and read its tables.
 */
add_action( 'plugins_loaded', function () {
	load_plugin_textdomain( 'clientum-user-dashboard', false, dirname( plugin_basename( CUD_PLUGIN_FILE ) ) . '/languages' );

	$dashboard = new Dashboard();
	$dashboard->init();

	$rest = new RestController();
	$rest->init();
} );
