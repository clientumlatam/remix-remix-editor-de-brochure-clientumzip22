<?php

if (!defined('ABSPATH')) exit;


use MailPoetVendor\Twig\Environment;
use MailPoetVendor\Twig\Error\LoaderError;
use MailPoetVendor\Twig\Error\RuntimeError;
use MailPoetVendor\Twig\Extension\CoreExtension;
use MailPoetVendor\Twig\Extension\SandboxExtension;
use MailPoetVendor\Twig\Markup;
use MailPoetVendor\Twig\Sandbox\SecurityError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedTagError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedFilterError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedFunctionError;
use MailPoetVendor\Twig\Source;
use MailPoetVendor\Twig\Template;

/* logs.html */
class __TwigTemplate_176225ef6518abb3a235b9f1785c332f068c4c798b602f397b3f290225c58508 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html", "logs.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        yield "
<div class=\"wrap\">
  <h1 class=\"mailpoet-h1\">Logs</h1>

  <div id=\"mailpoet_logs_container\"></div>

  <script type=\"text/javascript\">
    ";
        // line 12
        yield "      var mailpoet_logs_default_from = '";
        yield $this->env->getRuntime('MailPoetVendor\Twig\Runtime\EscaperRuntime')->escape(($context["logs_default_from"] ?? null), "js", null, true);
        yield "';
      var mailpoet_logs_filter_options = ";
        // line 13
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["logs_filter_options"] ?? null));
        yield ";
      var mailpoet_logs_api = ";
        // line 14
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["api"] ?? null));
        yield ";
      var mailpoet_logs_download = ";
        // line 15
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["download"] ?? null));
        yield ";
    ";
        // line 17
        yield "  </script>
</div>

";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "logs.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  77 => 17,  73 => 15,  69 => 14,  65 => 13,  60 => 12,  51 => 4,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "logs.html", "/home/circleci/mailpoet/mailpoet/views/logs.html");
    }
}
