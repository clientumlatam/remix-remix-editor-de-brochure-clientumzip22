<?php

if (!defined('ABSPATH')) exit;


use MailPoetVendor\Twig\Environment;
use MailPoetVendor\Twig\Error\LoaderError;
use MailPoetVendor\Twig\Error\RuntimeError;
use MailPoetVendor\Twig\Extension\CoreExtension;
use MailPoetVendor\Twig\Extension\SandboxExtension;
use MailPoetVendor\Twig\Markup;
use MailPoetVendor\Twig\Sandbox\SecurityError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedTagError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedFilterError;
use MailPoetVendor\Twig\Sandbox\SecurityNotAllowedFunctionError;
use MailPoetVendor\Twig\Source;
use MailPoetVendor\Twig\Template;

/* subscribers/subscribers.html */
class __TwigTemplate_70c39d9791cbbcea05d3fbbb309cad375978ada7981fa12e84ee320845b9d3ad extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'after_translations' => [$this, 'block_after_translations'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html", "subscribers/subscribers.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        yield "  <div id=\"subscribers_container\"></div>

  <script type=\"text/javascript\">
    var mailpoet_listing_per_page = ";
        // line 7
        yield $this->env->getRuntime('MailPoetVendor\Twig\Runtime\EscaperRuntime')->escape(($context["items_per_page"] ?? null), "html", null, true);
        yield ";
    var mailpoet_segments = ";
        // line 8
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["segments"] ?? null));
        yield ";
    var mailpoet_custom_fields = ";
        // line 9
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["custom_fields"] ?? null));
        yield ";
    var mailpoet_month_names = ";
        // line 10
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["month_names"] ?? null));
        yield ";
    var mailpoet_date_formats = ";
        // line 11
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["date_formats"] ?? null));
        yield ";
    var mailpoet_signup_confirmation_enabled = ";
        // line 12
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["signup_confirmation_enabled"] ?? null));
        yield ";
    var mailpoet_bulk_confirmation_resend_limit = ";
        // line 13
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["bulk_confirmation_resend_limit"] ?? null));
        yield ";
    var mailpoet_subscribers_api = ";
        // line 14
        yield $this->extensions['MailPoet\Twig\Functions']->jsonEncode(($context["api"] ?? null));
        yield ";
  </script>

  ";
        // line 17
        yield $this->extensions['MailPoet\Twig\I18n']->localize(["bouncedSubscribersHelp" => $this->extensions['MailPoet\Twig\I18n']->translate("Email addresses that are invalid or don't exist anymore are called \"bounced addresses\". It's a good practice not to send emails to bounced addresses to keep a good reputation with spam filters. Send your emails with MailPoet and we'll automatically ensure to keep a list of bounced addresses without any setup."), "bouncedSubscribersPremiumButtonText" => $this->extensions['MailPoet\Twig\I18n']->translate("Get premium version!"), "edit" => $this->extensions['MailPoet\Twig\I18n']->translate("Edit"), "trash" => $this->extensions['MailPoet\Twig\I18n']->translate("Trash"), "moveToTrash" => $this->extensions['MailPoet\Twig\I18n']->translate("Move to trash"), "showMoreDetails" => $this->extensions['MailPoet\Twig\I18n']->translate("Show more details"), "lastEngagement" => $this->extensions['MailPoet\Twig\I18n']->translate("Last engagement"), "never" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("never", "when was the last time the subscriber engaged with the website?"), "email" => $this->extensions['MailPoet\Twig\I18n']->translate("E-mail"), "firstname" => $this->extensions['MailPoet\Twig\I18n']->translate("First name"), "lastname" => $this->extensions['MailPoet\Twig\I18n']->translate("Last name"), "status" => $this->extensions['MailPoet\Twig\I18n']->translate("Status"), "unconfirmed" => $this->extensions['MailPoet\Twig\I18n']->translate("Unconfirmed"), "subscribed" => $this->extensions['MailPoet\Twig\I18n']->translate("Subscribed"), "unsubscribed" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed"), "inactive" => $this->extensions['MailPoet\Twig\I18n']->translate("Inactive"), "bounced" => $this->extensions['MailPoet\Twig\I18n']->translate("Bounced"), "selectList" => $this->extensions['MailPoet\Twig\I18n']->translate("Select a list"), "unsubscribedOn" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed on %1\$s"), "subscriberUpdated" => $this->extensions['MailPoet\Twig\I18n']->translate("Subscriber was updated successfully!"), "subscriberAdded" => $this->extensions['MailPoet\Twig\I18n']->translate("Subscriber was added successfully!"), "welcomeEmailTip" => $this->extensions['MailPoet\Twig\I18n']->translate("This subscriber will receive Welcome Emails if any are active for your lists."), "unsubscribedNewsletter" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed at %1\$d, from newsletter [link]."), "unsubscribedManage" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed at %1\$d, using the “Manage my Subscription” page."), "unsubscribedAdmin" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed at %1\$d, by admin \"%2\$d\"."), "unsubscribedMpApi" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed at %1\$d, via the MP API."), "unsubscribedUnknown" => $this->extensions['MailPoet\Twig\I18n']->translate("Unsubscribed at %1\$d, for an unknown reason."), "unsubscribeReason" => $this->extensions['MailPoet\Twig\I18n']->translate("Reason: %1\$s."), "unsubscribeReasonWithDetails" => $this->extensions['MailPoet\Twig\I18n']->translate("Reason: %1\$s. Details: %2\$s"), "subscriber" => $this->extensions['MailPoet\Twig\I18n']->translate("Subscriber"), "status" => $this->extensions['MailPoet\Twig\I18n']->translate("Status"), "lists" => $this->extensions['MailPoet\Twig\I18n']->translate("Lists"), "statisticsColumn" => $this->extensions['MailPoet\Twig\I18n']->translate("Score"), "subscribedOn" => $this->extensions['MailPoet\Twig\I18n']->translate("Subscribed on"), "createdOn" => $this->extensions['MailPoet\Twig\I18n']->translate("Created on"), "lastModifiedOn" => $this->extensions['MailPoet\Twig\I18n']->translate("Last modified on"), "oneSubscriberTrashed" => $this->extensions['MailPoet\Twig\I18n']->translate("1 subscriber was moved to the trash."), "multipleSubscribersTrashed" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were moved to the trash."), "oneSubscriberDeleted" => $this->extensions['MailPoet\Twig\I18n']->translate("1 subscriber was permanently deleted."), "multipleSubscribersDeleted" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were permanently deleted."), "oneSubscriberRestored" => $this->extensions['MailPoet\Twig\I18n']->translate("1 subscriber has been restored from the trash."), "multipleSubscribersRestored" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers have been restored from the trash."), "moveToList" => $this->extensions['MailPoet\Twig\I18n']->translate("Move to list..."), "multipleSubscribersMovedToList" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were moved to list <strong>%2\$s</strong>"), "addToList" => $this->extensions['MailPoet\Twig\I18n']->translate("Add to list..."), "multipleSubscribersAddedToList" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were added to list <strong>%2\$s</strong>."), "removeFromList" => $this->extensions['MailPoet\Twig\I18n']->translate("Remove from list..."), "multipleSubscribersRemovedFromList" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were removed from list <strong>%2\$s</strong>"), "removeFromAllLists" => $this->extensions['MailPoet\Twig\I18n']->translate("Remove from all lists"), "unsubscribe" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("Unsubscribe", "This is an action on the subscribers page"), "unsubscribeConfirm" => $this->extensions['MailPoet\Twig\I18n']->translate("This action will unsubscribe %s subscribers from all lists. This action cannot be undone. Are you sure, you want to continue?"), "multipleSubscribersRemovedFromAllLists" => $this->extensions['MailPoet\Twig\I18n']->translate("%1\$d subscribers were removed from all lists."), "resendConfirmationEmail" => $this->extensions['MailPoet\Twig\I18n']->translate("Resend confirmation email"), "oneConfirmationEmailSent" => $this->extensions['MailPoet\Twig\I18n']->translate("1 confirmation email has been sent."), "listsToWhichSubscriberWasSubscribed" => $this->extensions['MailPoet\Twig\I18n']->translate("Lists to which the subscriber was subscribed."), "WPUsersSegment" => $this->extensions['MailPoet\Twig\I18n']->translate("WordPress Users"), "WPUserEditNotice" => $this->extensions['MailPoet\Twig\I18n']->translate("This subscriber is a registered WordPress user. [link]Edit their profile[/link] to change their email."), "statsListingActionTitle" => $this->extensions['MailPoet\Twig\I18n']->translate("Statistics"), "statsSentEmail" => $this->extensions['MailPoet\Twig\I18n']->translate("Sent email"), "statsOpened" => $this->extensions['MailPoet\Twig\I18n']->translate("Opened"), "statsMachineOpened" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("Machine-opened", "Percentage of newsletters that were opened by a machine"), "statsMachineOpenedTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("A machine-opened email is an email opened by a computer in the background without the user’s explicit request or knowledge. [link]Read more[/link]"), "statsClicked" => $this->extensions['MailPoet\Twig\I18n']->translate("Clicked"), "statsNotClicked" => $this->extensions['MailPoet\Twig\I18n']->translate("Not opened"), "tip" => $this->extensions['MailPoet\Twig\I18n']->translate("Tip:"), "customFieldsTip" => $this->extensions['MailPoet\Twig\I18n']->translate("Need to add new fields, like a telephone number or street address? You can add custom fields by editing the subscription form on the Forms page."), "year" => $this->extensions['MailPoet\Twig\I18n']->translate("Year"), "month" => $this->extensions['MailPoet\Twig\I18n']->translate("Month"), "day" => $this->extensions['MailPoet\Twig\I18n']->translate("Day"), "save" => $this->extensions['MailPoet\Twig\I18n']->translate("Save"), "backToList" => $this->extensions['MailPoet\Twig\I18n']->translate("Back"), "premiumFeature" => $this->extensions['MailPoet\Twig\I18n']->translate("This is a Premium feature"), "upgradeRequired" => $this->extensions['MailPoet\Twig\I18n']->translate("Upgrade required"), "freeLimitReached" => $this->extensions['MailPoet\Twig\I18n']->translate("Congratulations, you now have [subscribersCount] subscribers! Our free version is limited to [subscribersLimit] subscribers. You need to upgrade now to be able to continue using MailPoet."), "planLimitReached" => $this->extensions['MailPoet\Twig\I18n']->translate("Congratulations, you now have [subscribersCount] subscribers! Your plan is limited to [subscribersLimit] subscribers. You need to upgrade now to be able to continue using MailPoet."), "premiumBannerCtaFree" => $this->extensions['MailPoet\Twig\I18n']->translate("Upgrade"), "premiumBannerCtaUpgrade" => $this->extensions['MailPoet\Twig\I18n']->translate("Upgrade Now"), "premiumFeatureDescription" => $this->extensions['MailPoet\Twig\I18n']->translate("Your current MailPoet plan includes advanced features, but they require the MailPoet Premium plugin to be installed and activated."), "premiumFeatureButtonDownloadPremium" => $this->extensions['MailPoet\Twig\I18n']->translate("Download MailPoet Premium plugin"), "premiumFeatureButtonActivatePremium" => $this->extensions['MailPoet\Twig\I18n']->translate("Activate MailPoet Premium plugin"), "premiumFeatureDescriptionSubscribersLimitReached" => $this->extensions['MailPoet\Twig\I18n']->translate("Congratulations, you now have [subscribersCount] subscribers! Your plan is limited to [subscribersLimit] subscribers. You need to upgrade now to be able to continue using MailPoet."), "premiumFeatureButtonUpgradePlan" => $this->extensions['MailPoet\Twig\I18n']->translate("Upgrade your plan"), "columnAction" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("Action", "Table column label for subscriber actions e.g. email open, link clicked"), "columnActionOn" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("Action on", "Table column label for date when subscriber action happened"), "columnCount" => $this->extensions['MailPoet\Twig\I18n']->translateWithContext("Count", "Table column label for count of subscriber actions"), "unknownBadgeName" => $this->extensions['MailPoet\Twig\I18n']->translate("Unknown"), "unknownBadgeTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("Not enough data."), "tooltipUnknown" => $this->extensions['MailPoet\Twig\I18n']->translate("Fewer than 3 emails sent ever"), "dormantBadgeName" => $this->extensions['MailPoet\Twig\I18n']->translate("Dormant"), "dormantBadgeTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("Not enough recent data."), "tooltipDormant" => $this->extensions['MailPoet\Twig\I18n']->translate("Fewer than 3 emails sent in the last year"), "excellentBadgeName" => $this->extensions['MailPoet\Twig\I18n']->translate("Excellent"), "excellentBadgeTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("Congrats!"), "tooltipExcellent" => $this->extensions['MailPoet\Twig\I18n']->translate("Read 50% or more of sent emails"), "goodBadgeName" => $this->extensions['MailPoet\Twig\I18n']->translate("Good"), "goodBadgeTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("Good stuff."), "tooltipGood" => $this->extensions['MailPoet\Twig\I18n']->translate("Read between 20 and 50% of sent emails"), "averageBadgeName" => $this->extensions['MailPoet\Twig\I18n']->translate("Low"), "averageBadgeTooltip" => $this->extensions['MailPoet\Twig\I18n']->translate("Something to improve."), "tooltipAverage" => $this->extensions['MailPoet\Twig\I18n']->translate("Read 20% or fewer of sent emails"), "engagementScoreDescription" => $this->extensions['MailPoet\Twig\I18n']->translate("Average percent of emails subscribers read in the last year"), "recalculateNow" => $this->extensions['MailPoet\Twig\I18n']->translate("Recalculate now"), "tags" => $this->extensions['MailPoet\Twig\I18n']->translate("Tags"), "addNewTag" => $this->extensions['MailPoet\Twig\I18n']->translate("Add new tag"), "tagAddedToMultipleSubscribers" => $this->extensions['MailPoet\Twig\I18n']->translate("Tag <strong>%1\$s</strong> was added to %2\$d subscribers."), "tagRemovedFromMultipleSubscribers" => $this->extensions['MailPoet\Twig\I18n']->translate("Tag <strong>%1\$s</strong> was removed from %2\$d subscribers."), "addTag" => $this->extensions['MailPoet\Twig\I18n']->translate("Add tag..."), "removeTag" => $this->extensions['MailPoet\Twig\I18n']->translate("Remove tag...")]);
        // line 130
        yield "
";
        return; yield '';
    }

    // line 133
    public function block_after_translations($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 134
        yield do_action("mailpoet_subscribers_translations_after");
        yield "
";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "subscribers/subscribers.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  103 => 134,  99 => 133,  93 => 130,  91 => 17,  85 => 14,  81 => 13,  77 => 12,  73 => 11,  69 => 10,  65 => 9,  61 => 8,  57 => 7,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "subscribers/subscribers.html", "/home/circleci/mailpoet/mailpoet/views/subscribers/subscribers.html");
    }
}
