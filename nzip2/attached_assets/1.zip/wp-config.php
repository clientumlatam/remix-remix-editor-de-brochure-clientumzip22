<?php
define('WP_CACHE', true); // Added by SpeedyCache

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'gamanferreteriac_wp268' );

/** Database username */
define( 'DB_USER', 'gamanferreteriac_wp268' );

/** Database password */
define( 'DB_PASSWORD', '4]0J6[S4bp' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'woqrnpllo084pdzxtra3q8dckcieharp5gbur0nv4p6thhha3j24mwhduqvzupvo' );
define( 'SECURE_AUTH_KEY',  'pfmnoygvc8dhhl6urvv2pqctal77rs20i6wq1xzymw6bh340md9aqxxpvkqeexbp' );
define( 'LOGGED_IN_KEY',    's8dyhbzovpufnlzmfhuiryuffxfljogbpfexx0guhszrnj5mgr6tdxtcjwzyq7kh' );
define( 'NONCE_KEY',        'catnowfhvpvng14anvr8iujrsw3geqspn1tohsmjisl6fhxshk5d15eus85mr7rp' );
define( 'AUTH_SALT',        'sbizrjysldoc63jm7ck2mx408abaa1t06tkq2puj8ec8kb3ffdc1awawfvqfdzg5' );
define( 'SECURE_AUTH_SALT', 'wwnxwzsxdpijkuuk7pyxvltk9p5mphasjey0peswalplodjzyumazioqp5wmfuow' );
define( 'LOGGED_IN_SALT',   'iqpgaao2mtpumyffnwvmcvlhn5cwkkmbf4ozn0bmcbq4c8mg2vqrkecl5lehy5hw' );
define( 'NONCE_SALT',       'eq35w8v31pn7ewo6oooezvl0umr0wqvp9k7nwm6yxyx6rna0vk7x89wbyry2tvmo' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wpst_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
